﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class CollectableSkill : MonoBehaviour
{
    public FighterSkill skill;
    
    private void Awake()
    {
        UpdateIcon();
    }

    private void Start()
    {
        if (Game.player.GetComponent<Fighter>().skills.Contains(skill))
        {
            gameObject.SetActive(false);
        }
    }

    private void OnDrawGizmos() => UpdateIcon();

    private void UpdateIcon()
    {
        GetComponent<SpriteRenderer>().sprite = skill.Icon;
    }
}
